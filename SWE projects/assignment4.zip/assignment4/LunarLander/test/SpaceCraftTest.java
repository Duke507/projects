import static org.junit.Assert.*;

import org.junit.Test;

public class SpaceCraftTest {

	@Test
	public void testCalcNewValues() {
		SpaceCraft sc = new SpaceCraft();
		
		sc.init();
		assertEquals(0, sc.getBurnRate());
		
		sc.setBurnRate(1000);
		try {
			sc.calcNewValues();
			fail("Exception should be thrown");
		} catch (Exception e) {
			;
		}
		sc.setBurnRate(5);
		sc.setFuel(45);
		try {
			sc.calcNewValues();
		} catch (Exception e) {
			;
		}
		assertEquals(40, sc.getFuel());
		
		sc.setVelocity(10);
		sc.setAltitude(1);
		sc.setFuel(100);
		sc.setBurnRate(0);
		try {
			sc.calcNewValues();
		} catch (Exception e) {
			;
		}
		assertEquals(0, sc.getAltitude()) ;
		
	}

	@Test
	public void testSetAltitude() {
		int altitude = 100;
		SpaceCraft sc = new SpaceCraft();
		sc.setAltitude(altitude);
		assertEquals(altitude, sc.getAltitude());
	}

}
